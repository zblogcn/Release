﻿///////////////////////////////////////////////////////////////////////////////
//              Z-Blog
// 作    者:    朱煊(zx.asd)
// 版权所有:    RainbowSoft Studio
// 技术支持:    rainbowsoft@163.com
// 程序名称:    
// 程序版本:    
// 单元名称:    common.js
// 开始时间:    2004.07.25
// 最后修改:    
// 备    注:    全局脚本
///////////////////////////////////////////////////////////////////////////////


var ZC_UBB_FACE_FILENAME="Sly smile|Big smile|Biggest smile|Tease|Starry|Flattered|Boy smile|Girl smile 3|Happy|Kissed|Surprise|Split|Fright|Capo mafioso|Sad|Bad surprise|Fear|Closed up|Cry|Fury|Alien|Bloody|Bomb|Hatred|Song|Prodigy|Snowman|Yin-yang|Mail|Blue"




//*********************************************************
// 目的：    加载样式表
// 输入：    无
// 返回：    无
//*********************************************************
function LoadActiveStyleSheet(){

	var title=GetCookie("sk")
	var a;

	if (title) {

		a = document.getElementsByTagName("link")[0];

		a.href=str00+"style/"+title+".css"

	}

}
//*********************************************************




//*********************************************************
// 目的：    设置样式表
// 输入：    title
// 返回：    无
//*********************************************************
function SetActiveStyleSheet(title){

	var a;

	if (title) {

		{
			SetCookie("sk",title,365);
		}
		a = document.getElementsByTagName("link")[0];

		a.href=str00+"style/"+title+".css"

	}

}
//*********************************************************




//*********************************************************
// 目的：    设置Cookie
// 输入：    sName, sValue,iExpireDays
// 返回：    无
//*********************************************************
function SetCookie(sName, sValue,iExpireDays) {
	if (iExpireDays){
		var dExpire = new Date();
		dExpire.setTime(dExpire.getTime()+parseInt(iExpireDays*24*60*60*1000));
		document.cookie = sName + "=" + escape(sValue) + "; expires=" + dExpire.toGMTString();
	}
	else{
		document.cookie = sName + "=" + escape(sValue);
	}
}
//*********************************************************




//*********************************************************
// 目的：    返回Cookie
// 输入：    Name
// 返回：    Cookie值
//*********************************************************
function GetCookie(sName) {

	var arr = document.cookie.match(new RegExp("(^| )"+sName+"=([^;]*)(;|$)"));
	if(arr !=null){return unescape(arr[2])};
	return null;

}
//*********************************************************




//*********************************************************
// 目的：    验证信息
// 输入：    无
// 返回：    无
//*********************************************************
function VerifyMessage() {

	var strName=document.getElementById("inpName").value;
	var strEmail=document.getElementById("inpEmail").value;
	var strHomePage=document.getElementById("inpHomePage").value;
	var strArticle;

	if(document.getElementById("txaArticle").value){
		strArticle=document.getElementById("txaArticle").value;
	}
	else{
		strArticle=document.getElementById("txaArticle").innerText;
	}

	if(strName==""){
		alert(str01);
		return false;
	}
	else{
		re = new RegExp("^[.A-Za-z0-9\u4e00-\u9fa5]+$");
		if (!re.test(strName)){
			alert(str02);
			return false;
		}
	}

	if(strEmail==""){
		alert(str01);
		return false;
	}
	else{
		re = new RegExp("^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$");
		if (!re.test(strEmail)){
			alert(str02);
			return false;
		}
	}

	if(typeof(strArticle)=="undefined"){
		alert(str03);
		return false;
	}

	if(typeof(strArticle)=="string"){
		if(strArticle==""){
			alert(str03);
			return false;
		}
		if(strArticle.length>intMaxLen)
		{
			alert(str03);
			return false;
		}
	}

	document.getElementById("inpArticle").value=strArticle;
	document.getElementById("inpLocation").value=parent.window.location.href;
	document.getElementById("frmSumbit").action=str00+"cmd.asp?act=cmt";


	var bolRemember=document.getElementById("chkRemember").checked;

	if(bolRemember==true){
		SaveRememberInfo();
	}
	else{
		SetCookie("chkRemember",bolRemember,365);
	}

}
//*********************************************************




//*********************************************************
// 目的：    加载信息
// 输入：    无
// 返回：    无
//*********************************************************
function LoadRememberInfo() {

	var strName=GetCookie("inpName")
	var strEmail=GetCookie("inpEmail")
	var strHomePage=GetCookie("inpHomePage")
	var bolRemember=GetCookie("chkRemember")

	if(bolRemember=="true"){

		if(strName){document.getElementById("inpName").value=strName;};
		if(strEmail){document.getElementById("inpEmail").value=strEmail;};
		if(strHomePage){document.getElementById("inpHomePage").value=strHomePage;};
		if(bolRemember){document.getElementById("chkRemember").checked=bolRemember;};

	}

}
//*********************************************************




//*********************************************************
// 目的：    保存信息
// 输入：    无
// 返回：    无
//*********************************************************
function SaveRememberInfo() {

	var strName=document.getElementById("inpName").value;
	var strEmail=document.getElementById("inpEmail").value;
	var strHomePage=document.getElementById("inpHomePage").value;
	var bolRemember=document.getElementById("chkRemember").checked;


	SetCookie("inpName",strName,365);
	SetCookie("inpEmail",strEmail,365);
	SetCookie("inpHomePage",strHomePage,365);
	SetCookie("chkRemember",bolRemember,365);

}
//*********************************************************





//*********************************************************
// 目的：    输出UBB
// 输入：    无
// 返回：    无
//*********************************************************
function ExportUbbFrame() {

	document.write("<p id=\"UbbFrame\" style=\"display:none;\">")

	var aryFileName;
	var strFileName;
	aryFileName = ZC_UBB_FACE_FILENAME.split("|");

	for (var i=0;i<aryFileName.length;i++)
	{
		strFileName = aryFileName[i];
		document.write("<img src=\""+str00+"image/face/"+strFileName+".gif\" title=\""+strFileName+"\" alt=\""+strFileName+"\" width=\"48\" height=\"48\" onclick=\"InsertUbbCode('[FACE]',this.alt);\" style=\"padding:2px;cursor:pointer;\">")
	}

	document.write("</p><p>")


	document.write("<a alt=\"\" onclick=\"InsertUbbCode('[URL]','');\" style=\"padding:2px;cursor:pointer;\">[URL]</a>  ")
	document.write("<a alt=\"\" onclick=\"InsertUbbCode('[EMAIL]','');\" style=\"padding:2px;cursor:pointer;\">[EMAIL]</a>  ")
	document.write("<a alt=\"\" onclick=\"InsertUbbCode('[B]','');\" style=\"padding:2px;cursor:pointer;\">[B]</a>  ")
	document.write("<a alt=\"\" onclick=\"InsertUbbCode('[I]','');\" style=\"padding:2px;cursor:pointer;\">[I]</a>  ")
	document.write("<a alt=\"\" onclick=\"InsertUbbCode('[QUOTE]','');\" style=\"padding:2px;cursor:pointer;\">[QUOTE]</a>  ")
	//document.write("<a alt=\"\" onclick=\"InsertUbbCode('[CODE]','');\" style=\"padding:2px;cursor:pointer;\">[CODE]</a>  ")

	document.write("<u><a style=\"cursor:pointer;text-align:right;\" onclick=\"if(document.getElementById('UbbFrame').style.display=='none'){document.getElementById('UbbFrame').style.display='block';}else{document.getElementById('UbbFrame').style.display='none'};this.style.display='none'\">"+str06+"</a></u> ")

	document.write("</p>")
}
//*********************************************************




//*********************************************************
// 目的：    输出UBB
// 输入：    无
// 返回：    无
//*********************************************************
function InsertUbbCode(strUbbType,strUbbName) {

	var strUbbCode="";

	if(strUbbType=="[URL]"){
		strUbbCode="[URL]" + strUbbName + "[/URL]";
	}
	if(strUbbType=="[EMAIL]"){
		strUbbCode="[EMAIL]" + strUbbName + "[/EMAIL]";
	}
	if(strUbbType=="[QUOTE]"){
		strUbbCode="[QUOTE]" + strUbbName + "[/QUOTE]";
	}
	if(strUbbType=="[CODE]"){
		strUbbCode="[CODE]" + strUbbName + "[/CODE]";
	}
	if(strUbbType=="[B]"){
		strUbbCode="[B]" + strUbbName + "[/B]";
	}
	if(strUbbType=="[I]"){
		strUbbCode="[I]" + strUbbName + "[/I]";
	}
	if(strUbbType=="[FACE]"){
		strUbbCode="[F]" + strUbbName + "[/F]";
	}

	document.getElementById("txaArticle").value=document.getElementById("txaArticle").value + strUbbCode;

}
//*********************************************************