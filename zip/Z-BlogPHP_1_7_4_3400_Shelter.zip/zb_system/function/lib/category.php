<?php

if (!defined('ZBP_PATH')) {
    exit('Access denied');
}

class Category extends Base__Category
{

}
