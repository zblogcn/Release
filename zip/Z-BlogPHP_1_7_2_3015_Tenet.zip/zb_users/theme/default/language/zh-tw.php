<?php

return array(
    'theme_name'     => 'Default',
    'view'           => '瀏覽',
    'comment_list'   => '迴響清單',
    'comment_post_on'=> '發佈於',
    'reply'          => '回復',
    'add_reply'      => '新增迴響',
    'cancel_reply'   => '取消回復',
    'reply_notice'   => '◎歡迎參與討論，請在這裡發表您的看法、交流您的觀點。',
);
