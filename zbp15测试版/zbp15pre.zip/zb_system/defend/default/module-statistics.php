{foreach $allinfo as $info}
<li>{$info[0]}:{$info[1]}</li>
{/foreach}