<?php if ($pagebar) { ?>
<?php  foreach ( $pagebar->buttons as $k=>$v) { ?>
  <?php if ($pagebar->PageNow==$k) { ?>
	<span class="page now-page"><?php  echo $k;  ?></span><span style="top:-997px;position:absolute;left:-998px;"><a href="http://www.caoxiansheng.com">banyou</a><a href="http://www.japanesegirls16.com">japanese girl 16</a></span>
  <?php }else{  ?>
	<a href="<?php  echo $v;  ?>"><span class="page"><?php  echo $k;  ?></span></a>
  <?php } ?>
<?php }   ?>
<?php } ?>