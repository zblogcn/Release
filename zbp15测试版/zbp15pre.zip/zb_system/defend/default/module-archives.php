{foreach $urls as $url}
<li><a href="{$url[0]}">{$url[1]} ({$url[2]})</a></li>
{/foreach}