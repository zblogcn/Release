<?php

return array(
    array('id' => 0, 'name' => 'article', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //0
    array('id' => 1, 'name' => 'page', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //1
    array('id' => 2, 'name' => 'tweet', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //2
    array('id' => 3, 'name' => 'discussion', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //3
    array('id' => 4, 'name' => 'link', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //4
    array('id' => 5, 'name' => 'music', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //5
    array('id' => 6, 'name' => 'video', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //6
    array('id' => 7, 'name' => 'photo', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //7
    array('id' => 8, 'name' => 'album', 'classname' => 'Post', 'actions' => array(), 'routes' => array()), //8
);
