<?php

if (!defined('ZBP_PATH')) {
    exit('Access denied');
}
/**
 * 用户类.
 * 继承自BaseMember
 */
class Member extends Base__Member
{

}
