<?php

if (!defined('ZBP_PATH')) {
    exit('Access denied');
}


class Upload extends Base__Upload
{

}
