<?php  foreach ( $sidebar2 as $module) { ?> 
<?php  include $this->GetTemplate('module');  ?>
<?php  }   ?>