<div class="post istop">
	<h2 class="post-title"><a href="{$article.Url}">{$article.Title}</a></h2>
</div>