// I18N constants
// Author: Jonathan Ernst, <Jonathan.Ernst@NetOxygen.ch>
// LANG: "fr", ENCODING: UTF-8 | ISO-8859-1

// FOR TRANSLATORS:
//
//   1. PLEASE PUT YOUR CONTACT INFO IN THE ABOVE LINE
//      (at least a valid email address)
//
//   2. PLEASE TRY TO USE UTF-8 FOR ENCODING;
//      (if this is not possible, please include a comment
//       that states what encoding is necessary.)

HTMLArea.I18N = {

	// the following should be the filename without .js extension
	// it will be used for automatically load plugin language.
	lang: "fr",

	tooltips: {
		bold:           "Gras",
		italic:         "Italique",
		underline:      "Soulign�",
		strikethrough:  "Barr�",
		subscript:      "Subscript",
		superscript:    "Superscript",
		justifyleft:    "Align� � gauche",
		justifycenter:  "Centr�",
		justifyright:   "Align� � droite",
		justifyfull:    "Justifi�",
		insertorderedlist:    "liste ordonn�e",
		insertunorderedlist:  "liste non ordonn�e",
		outdent:        "Augmenter le retrait",
		indent:         "Diminuer le retrait",
		forecolor:      "Couleur du texte",
		hilitecolor:    "Couleur du fond",
		horizontalrule: "Ligne horizontale",
		createlink:     "Ins�rer un lien",
		insertimage:    "Ins�rer une image",
		inserttable:    "Ins�rer un tableau",
		htmlmode:       "Passer au code source HTML",
		popupeditor:    "Agrandir l'�diteur",
		about:          "A propos de cet �diteur",
		showhelp:       "Aide sur l'�diteur",
		textindicator:  "Style courant",
		undo:           "Annule la derni�re action",
		redo:           "Refait la derni�re action",
		cut:            "Coupe la s�lection",
		copy:           "Copie la s�lection",
		paste:          "Colle depuis le presse papiers"
		lefttoright:    "Direction de gauche � droite",
		righttoleft:    "Direction de droite � gauche"
	},

	buttons: {
		"ok":           "OK",
		"cancel":       "Annuler"
	},

	msg: {
		"Path":         "Chemin",
		"TEXT_MODE":    "Vous �tes en mode texte.  Utilisez le bouton [<>] pour revenir au mode WYSIWIG."
		"IE-sucks-full-screen" :
		// translate here
		"Le mode plein �cran pose des probl�me avec Internet Explorer, " +
		"ceci �tant du � des bugs du navigateur que nous ne pouvons contourner.  Nous en avons fait l'exp�rience " +
		"Visualiser, � l'aide de fonctions d'�dition ou  al�atoires provoquera des crashes de votre navigateur.  Si votre syst�me est Windows 9x " +
		"un peu comme si vous provoquiez 'une faute de protection g�n�rale' et demandez de rebboter.\n\n" +
		"Vous avez �t� pr�venu.  Veuillez presser OK si vous d�sirez quand m�me essayer le mode plein �cran."
	},

	dialogs: {
		"Cancel"                                            : "Abandon",
		"Insert/Modify Link"                                : "Ins�rer/Modifier le lien",
		"New window (_blank)"                               : "Nouvelle fen�tre (_blank)",
		"None (use implicit)"                               : "Aucune (utilisation implicite)",
		"OK"                                                : "OK",
		"Other"                                             : "Autre",
		"Same frame (_self)"                                : "M�me frame (_self)",
		"Target:"                                           : "Cible:",
		"Title (tooltip):"                                  : "Titre (tooltip):",
		"Top frame (_top)"                                  : "Haut frame (_top)",
		"URL:"                                              : "URL:",
		"You must enter the URL where this link points to"  : "Vous devez rentrer l'URL sur lequel le lien devra pointer"
	}
};
