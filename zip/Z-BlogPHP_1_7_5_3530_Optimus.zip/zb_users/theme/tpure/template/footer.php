{* Template Name:公共底部(勿选) *}
<div class="footer">
    <div class="fademask"></div>
        <div class="wrap">
            <h3>{$copyright}</h3>
            <h4>Powered By {$zblogphpabbrhtml}. Theme by <a href="https://www.toyean.com/" target="_blank">TOYEAN</a>.</h4>
            {$footer}
        </div>
    </div>
</div>
<div class="edgebar"></div>
</body>
</html>