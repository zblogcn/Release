<?php if (!defined('ZBP_PATH')) {
    exit('Access denied');
} ?>
</section>
<?php
HookFilterPlugin('Filter_Plugin_Admin_Footer');
?>
</body>
</html>
