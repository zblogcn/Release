///////////////////////////////////////////////////////////////////////////////
//              Z-Blog
// 作    者:    朱煊(zx.asd)
// 版权所有:    RainbowSoft Studio
// 技术支持:    rainbowsoft@163.com
// 程序名称:    
// 程序版本:    
// 单元名称:    common.js
// 开始时间:    2004.07.25
// 最后修改:    
// 备    注:    全局脚本
///////////////////////////////////////////////////////////////////////////////





//*********************************************************
// 目的：    加载样式表
// 输入：    无
// 返回：    无
//*********************************************************
function LoadActiveStyleSheet(){

	var title=GetCookie("sk")
	var a;

	if (title) {

		a = document.getElementsByTagName("link")[0];

		a.href=str00+"style/"+title+".css"

	}

}
//*********************************************************




//*********************************************************
// 目的：    设置样式表
// 输入：    title
// 返回：    无
//*********************************************************
function SetActiveStyleSheet(title){

	var a;

	if (title) {

		{
			SetCookie("sk",title,365);
		}
		a = document.getElementsByTagName("link")[0];

		a.href=str00+"style/"+title+".css"

	}

}
//*********************************************************




//*********************************************************
// 目的：    设置Cookie
// 输入：    sName, sValue,iExpireDays
// 返回：    无
//*********************************************************
function SetCookie(sName, sValue,iExpireDays) {
	if (iExpireDays){
		var dExpire = new Date();
		dExpire.setTime(dExpire.getTime()+parseInt(iExpireDays*24*60*60*1000));
		document.cookie = sName + "=" + escape(sValue) + "; expires=" + dExpire.toGMTString();
	}
	else{
		document.cookie = sName + "=" + escape(sValue);
	}
}
//*********************************************************




//*********************************************************
// 目的：    返回Cookie
// 输入：    Name
// 返回：    Cookie值
//*********************************************************
function GetCookie(sName) {

	var arr = document.cookie.match(new RegExp("(^| )"+sName+"=([^;]*)(;|$)"));
	if(arr !=null){return unescape(arr[2])};
	return null;

}
//*********************************************************




//*********************************************************
// 目的：    验证信息
// 输入：    无
// 返回：    无
//*********************************************************
function VerifyMessage() {

	if ($('passForm')['style']['display']=='none')
	{	
		$('chkLogin').checked=false;	
		$('chkReg').checked=false;
	}
	
    var strName=$("inpName").value;
	var strEmail=$("inpEmail").value;
	var strHomePage=$("inpHomePage").value;
	var inpVerify=$("inpVerify").value;
	var inpPass=$("inpPass").value;
	var chkReg=$('chkReg').checked;
	var chkLogin=$('chkLogin').checked;
	
	var strArticle;
	var SendTime=20;
	var ADRegexp=/(url)|(http)|(www)/gi;

	var sDialog = new dialog();
	sDialog.init();

	if(getSend()<SendTime){
		sDialog.event(ZC_MSG247+':)<br/> '+ZC_MSG248.replace("%s",(SendTime - getSend())),'');
		sDialog.button('dialogOk','void 0');
		$('dialogOk').focus();
		return false;
	}

	if(strName==""){
		sDialog.event(str01,'');
		sDialog.button('dialogOk','void 0');
		$('dialogOk').focus();
		return false;
	}
	else{
		re = new RegExp("^[.A-Za-z0-9\u4e00-\u9fa5]+$");
		if (!re.test(strName)){
			sDialog.event(str02,'');
			sDialog.button('dialogOk','void 0');
			$('dialogOk').focus();
			return false;
		}
	}

	if (chkReg==true && chkLogin==false)
	{
		chkReg=1;chkLogin=0;
	}else if (chkReg==false && chkLogin==true)
	{
		chkReg=0;chkLogin=1;
	}else{
		chkReg=0;chkLogin=0;
	}

	if(inpPass!=""){
		inpPass=MD5(inpPass);
	}

	if(strEmail!=""){
		re = new RegExp("^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$");
		if (!re.test(strEmail)){
			sDialog.event(str02,'');
			sDialog.button('dialogOk','void 0');
			$('dialogOk').focus();
			return false;
		}
	}

	if($("txaArticle").value){
		strArticle=$("txaArticle").value;
	}
	else{
		strArticle=$("txaArticle").innerText;
	}


	if(typeof(strArticle)=="undefined"){
		sDialog.event(str03,'');
		sDialog.button('dialogOk','void 0');
		$('dialogOk').focus();
		return false;
	}

	if(typeof(strArticle)=="string"){
		if(strArticle==""){
			sDialog.event(str03,'');
			sDialog.button('dialogOk','void 0');
			$('dialogOk').focus();
			return false;
		}
		if(strArticle.length>intMaxLen)
		{
			sDialog.event(str03,'');
			sDialog.button('dialogOk','void 0');
			$('dialogOk').focus();
			return false;
		}
		if(strArticle.length<intMinLen){
			sDialog.event(str03,'');
			sDialog.button('dialogOk','void 0');
			$('dialogOk').focus();
			return false;
		}
		if (strArticle.match(new RegExp(ADRegexp))!=null)
		{
			if (strArticle.match(new RegExp(/www/gi))!=null)
			{
				if (strArticle.match(new RegExp(/www/gi)).length>1)
				{
				initSendTime();
				ReloadCheckImage();	
				sDialog.event(ZC_MSG255,'');
				sDialog.button('dialogOk','void 0');
				$('dialogOk').focus();
				return false;
				}
				
			}
			if (strArticle.match(new RegExp(/http/gi))!=null)
			{
				if (strArticle.match(new RegExp(/http/gi)).length>1)
				{
				initSendTime();
				ReloadCheckImage();	
				sDialog.event(ZC_MSG255,'');
				sDialog.button('dialogOk','void 0');
				$('dialogOk').focus();
				return false;
				}
			}
			if (strArticle.match(new RegExp(/url/gi))!=null)
			{
				if (strArticle.match(new RegExp(/url/gi)).length>2)
				{
				initSendTime();
				ReloadCheckImage();	
				sDialog.event(ZC_MSG255,'');
				sDialog.button('dialogOk','void 0');
				$('dialogOk').focus();
				return false;
				}
			}
		}

	}

    var xmlhttp=getHTTPObject();

	xmlhttp.open('POST', str00+'cmd.asp?act=cmt&random='+Math.random(), true); 
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
	xmlhttp.onreadystatechange = function(){
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
			switch(xmlhttp.responseText){
				case "inpVerify" :
					inpVerifyNumber=inpVerifyNumber+1;
				    if (inpVerifyNumber==3){
				    initSendTime();
					inpVerifyNumber=0;
					}
					sDialog.event(ZC_MSG249,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					ReloadCheckImage();
					return false;
				case "PassWordErr" :
					sDialog.event(ZC_MSG287,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;
				case "LoginFailed" :
					sDialog.event(ZC_MSG288,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;
				case "RegisterFailed" :
					sDialog.event(ZC_MSG288,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;					
				case "UserExist" :
					sDialog.event(ZC_MSG289,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;				
				case "Err6" :
					sDialog.event(ZC_MSG250.replace("%s",strName),'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;
				case "Err31" :
					sDialog.event(ZC_MSG251,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;
				case "RegisterSuccessOK" :
					if (ZC_COMMENT_STATIC_SHOW)
					{
					ReloadCheckImage();	
					initSendTime();
					sDialog.event(ZC_MSG291+ZC_MSG252,'');
					sDialog.button('dialogOk','disableform(false);location.reload();');
					$('dialogOk').focus();
					return false;
					}else{
					Comment_Initialize();	
					initSendTime();
					sDialog.event(ZC_MSG291+ZC_MSG252,'');
					sDialog.button('dialogOk','disableform(false);window.location.href="#CommentStr";');
					$('dialogOk').focus();
					ReloadCheckImage();	
					return false;
					}
				case "OK" :
					if (ZC_COMMENT_STATIC_SHOW)
					{
					ReloadCheckImage();	
					initSendTime();
					sDialog.event(ZC_MSG252,'');
					sDialog.button('dialogOk','disableform(false);location.reload();');
					$('dialogOk').focus();
					return false;
					}else{
					Comment_Initialize();	
					initSendTime();
					sDialog.event(ZC_MSG252,'');
					sDialog.button('dialogOk','disableform(false);window.location.href="#CommentStr";');
					$('dialogOk').focus();
					ReloadCheckImage();	
					return false;
					}
					
				case "same" :
					initSendTime();
					sDialog.event(ZC_MSG253,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					ReloadCheckImage();
					return false;
				default :
					sDialog.html(xmlhttp.responseText,'');
					sDialog.button('dialogOk','disableform(false);');
					$('dialogOk').focus();
					return false;

			}
		};
    }
	xmlhttp.send("inpVerify="+escape2(inpVerify)+"&inpID="+escape2($("inpId").value)+"&inpName="+escape2(strName)+"&inpArticle="+escape2(strArticle)+"&inpEmail="+escape2(strEmail)+"&inpHomePage="+escape2(strHomePage)+"&inpPass="+escape2(inpPass)+"&chkLogin="+escape2(chkLogin)+"&chkReg="+escape2(chkReg)+"");
	disableform(true);

	var bolRemember=$("chkRemember").checked;

	if(bolRemember==true){
		SaveRememberInfo();
	}
	else{
		SetCookie("chkRemember",bolRemember,365);
	}


	return false;	

}
//*********************************************************

function ReloadCheckImage(){

	var xmlhttp=getHTTPObject();
	xmlhttp.open('GET', str00+'c_html_js.asp?act=CommentVerify&random='+Math.random(), true); 
	xmlhttp.onreadystatechange = function(){
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ){
		$("chk_img1").src=$("chk_img1").src+'&random='+Math.random();
		$("chk_img2").src=$("chk_img2").src+'&random='+Math.random();
		$("chk_img3").src=$("chk_img3").src+'&random='+Math.random();
		$("chk_img4").src=$("chk_img4").src+'&random='+Math.random();
		}
    };
	xmlhttp.send(null);
}


//*********************************************************
// 目的：    加载信息
// 输入：    无
// 返回：    无
//*********************************************************
function LoadRememberInfo() {

	var strName=GetCookie("inpName")
	var strEmail=GetCookie("inpEmail")
	var strHomePage=GetCookie("inpHomePage")
	var bolRemember=GetCookie("chkRemember")

	if(bolRemember=="true"){

		if(strName){$("inpName").value=strName;};
		if(strEmail){$("inpEmail").value=strEmail;};
		if(strHomePage){$("inpHomePage").value=strHomePage;};
		if(bolRemember){$("chkRemember").checked=bolRemember;};

	}

}
//*********************************************************




//*********************************************************
// 目的：    保存信息
// 输入：    无
// 返回：    无
//*********************************************************
function SaveRememberInfo() {

	var strName=$("inpName").value;
	var strEmail=$("inpEmail").value;
	var strHomePage=$("inpHomePage").value;
	var bolRemember=$("chkRemember").checked;


	SetCookie("inpName",strName,365);
	SetCookie("inpEmail",strEmail,365);
	SetCookie("inpHomePage",strHomePage,365);
	SetCookie("chkRemember",bolRemember,365);

}
//*********************************************************





//*********************************************************
// 目的：    输出UBB
// 输入：    无
// 返回：    无
//*********************************************************
function ExportUbbFrame() {

	objActive="txaArticle";

	if (ZC_HIDE_EMOTION)
	{
		document.write("<p id=\"UbbFrame\" style=\"display:none;\"></p>")
	}else{
		document.write("<p id=\"UbbFrame\"></p>")
	    InsertUbbFace();
	}

	document.write("<p>")

	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[URL]','[/URL]'),true);\" style=\"padding:2px;cursor:pointer;\">[URL]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[URL=http://]','[/URL]'),true);\" style=\"padding:2px;cursor:pointer;\">[URL2]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[EMAIL]','[/EMAIL]'),true);\" style=\"padding:2px;cursor:pointer;\">[EMAIL]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[EMAIL=@]','[/EMAIL]'),true);\" style=\"padding:2px;cursor:pointer;\">[EMAIL2]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[B]','[/B]'),true);\" style=\"padding:2px;cursor:pointer;\">[B]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[I]','[/I]'),true);\" style=\"padding:2px;cursor:pointer;\">[I]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[U]','[/U]'),true);\" style=\"padding:2px;cursor:pointer;\">[U]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[S]','[/S]'),true);\" style=\"padding:2px;cursor:pointer;\">[S]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[QUOTE]','[/QUOTE]'),true);\" style=\"padding:2px;cursor:pointer;\">[QUOTE]</a>  ")

	if (ZC_HIDE_EMOTION)
	{
		document.write("<u><a style=\"cursor:pointer;text-align:right;\" onclick=\"InsertUbbFace();if(document.getElementById('UbbFrame').style.display=='none'){document.getElementById('UbbFrame').style.display='block';}else{document.getElementById('UbbFrame').style.display='none'};this.style.display='none'\">"+str06+"</a></u> ")
	}
	

	document.write("</p>")
}
//*********************************************************




//*********************************************************
// 目的：    插入表情图片HTML代码
// 输入：    无
// 返回：    无
//*********************************************************
function InsertUbbFace() {

	if(!$("UbbFrame").innerHTML){

		var aryFileName="";
		var strFileName="";
		var strFaceHtml="";

		aryFileName = strFaceName.split("|");

		for (var i=0;i<aryFileName.length;i++)
		{
			strFileName = aryFileName[i];
			strFaceHtml=strFaceHtml + "<img src=\""+str00+"image/face/"+strFileName+".gif\" title=\""+strFileName+"\" alt=\""+strFileName+"\" width=\""+strFaceSize+"\" height=\""+strFaceSize+"\" onclick=\"InsertText(objActive,'[F]'+this.alt+'[/F]',false);\" style=\"padding:2px;cursor:pointer;\">"
		}
		$("UbbFrame").innerHTML=strFaceHtml;
	}

}
//*********************************************************




//*********************************************************
// 目的：    自动插入并替换
// 输入：    无
// 返回：    无
//*********************************************************
var objActive;
function GetActiveText(objHTML) {
	objActive=objHTML;
	if(document.selection){
		var obj=$(objHTML);
		obj.currPos = document.selection.createRange().duplicate()
	}
}

function InsertText(objHTML,strText,bolReplace) {
	if(strText==""){return("")}
	var obj=$(objHTML);
	if(document.selection){
		if (obj.currPos){
			if(bolReplace && (obj.value=="")){
				obj.currPos.text=strText
			}
			else{
				obj.currPos.text+=strText
			}
		}
		else{
			obj.value+=strText
		}
	}
	else{
		if(bolReplace){
			obj.value=obj.value.slice(0,obj.selectionStart) + strText + obj.value.slice(obj.selectionEnd,obj.value.length)
		}
		else{
			obj.value=obj.value.slice(0,obj.selectionStart) + strText + obj.value.slice(obj.selectionStart,obj.value.length)
		}
	}
	//obj.focus();
}

function ReplaceText(objHTML,strPrevious,strNext) {
	var obj=$(objHTML);
	var strText;
	if(document.selection && document.selection.type == "Text"){
		if (obj.currPos){
			var range = document.selection.createRange();
			range.text = strPrevious + range.text + strNext;
			return("");
		}
		else{
			strText=strPrevious + strNext;
			return(strText);
		}
	}
	else{
		if(obj.selectionStart || obj.selectionEnd){
			strText=strPrevious + obj.value.slice(obj.selectionStart,obj.selectionEnd) + strNext;
			return(strText);
		}
		else{
			strText=strPrevious + strNext;
			return(strText);
		}
	}
}
//*********************************************************




//*********************************************************
// 目的：    ShowMedia By UBB
// 输入：    无
// 返回：    无
//*********************************************************
function ShowMedia(objHTML,strURL,strType,intWidth,intHeight)
{
	var strMedia="";
	var blnShow = false;
	var objMedia=objHTML;

	if(objMedia.innerHTML){blnShow = true};

	var re = new RegExp("\.[a-z0-9]+$","ig");

	var strExtend = re.exec(strURL);
	strExtend="|"+String(strExtend).toLowerCase()+"|";

	if(strType=="AUTO"){
		if(String("|.swf|").indexOf(strExtend)>=0){strType="SWF"}
		if(String("|.mov|.qt|").indexOf(strExtend)>=0){strType="QT"}
		if(String("|.wmv|.wmp|.wm|.avi|.mp4|.mpg|.mpeg|.m3u|.pls|.wvx|.wax|.wmx|").indexOf(strExtend)>=0){strType="WMV"}
		if(String("|.asf|.wma|.asx|.wav|.mp3|.mpa|.mp2|.m1a|.m2a|.aac|").indexOf(strExtend)>=0){strType="WMA"}
		if(String("|.rm|.ram|.rmvb|.rpm|.amr|.3gp|.3gpp|.3g2|.3gp2|.rt|.rp|.smi|.smil|").indexOf(strExtend)>=0){strType="RM"}
		if(String("|.ra|").indexOf(strExtend)>=0){strType="RA"}
	}

	if(blnShow){
		objMedia.innerHTML = strMedia;
	}
	else{
		switch(strType){
			case "SWF":
				strMedia="<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\""+intWidth+"\" height=\""+intHeight+"\"><param name=\"movie\" value=\""+strURL+"\"><param name=\"quality\" value=\"high\"><param name=\"play\" value=\"true\"><embed src=\""+strURL+"\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\""+intWidth+"\" height=\""+intHeight+"\" play=\"true\"></embed></object>"
				break;
			case "QT":
				strMedia="<object classid=\"clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B\" codebase=\"http://www.apple.com/qtactivex/qtplugin.cab\" width=\""+intWidth+"\" height=\""+intHeight+"\" ><param name=\"src\" value=\""+strURL+"\" ><param name=\"autoplay\" value=\"true\" ><embed  src=\"qtmimetype.pntg\" type=\"image/x-macpaint\"pluginspage=\"http://www.apple.com/quicktime/download\" qtsrc=\""+strURL+"\" width=\""+intHeight+"\" height=\""+intHeight+"\" autoplay=\"true\" ></embed></object>"
				break;
			case "WMV":
				strMedia="<object classid=\"clsid:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" width=\""+intWidth+"\" height=\""+intHeight+"\"><param name=\"ShowStatusBar\" value=\"-1\"><param name=\"AutoStart\" value=\"true\"><param name=\"Filename\" value=\""+strURL+"\"><embed type=\"application/x-mplayer2\" pluginspage=\"http://www.microsoft.com/Windows/MediaPlayer/\" src=\""+strURL+"\" autostart=\"true\" width=\""+intWidth+"\" height=\""+intHeight+"\"></embed></object>"
				break;
			case "WMA":
				strMedia="<object classid=\"clsid:22D6F312-B0F6-11D0-94AB-0080C74C7E95\" height=\"45\" width=\"350\"><param name=\"ShowStatusBar\" value=\"-1\"><param name=\"AutoStart\" value=\"true\"><param name=\"Filename\" value=\""+strURL+"\"><embed type=\"application/x-mplayer2\" pluginspage=\"http://www.microsoft.com/Windows/MediaPlayer/\" src=\""+strURL+"\" autostart=\"true\" width=\"350\" height=\"45\"></embed></object>"
				break;
			case "RM":
				strMedia="<object classid=\"clsid:CFCDAA03-8BE4-11CF-B84B-0020AFBBCCFA\" width=\""+intWidth+"\" height=\""+intWidth+"\"><param name=\"src\" value=\""+strURL+"\"><param name=\"controls\" value=\"imagewindow\"><param name=\"console\" value=\"one\"><param name=\"AutoStart\" value=\"true\"><embed src=\""+strURL+"\" width=\""+intWidth+"\" height=\""+intWidth+"\" type=\"audio/x-pn-realaudio-plugin\" nojava=\"true\" controls=\"imagewindow,ControlPanel,StatusBar\" console=\"one\" autostart=\"true\"></object>"
				break;
			case "RA":
				strMedia="<object classid=\"clsid:CFCDAA03-8BE4-11CF-B84B-0020AFBBCCFA\" width=\"350\" height=\"36\"><param name=\"src\" value=\""+strURL+"\"><param name=\"controls\" value=\"ControlPanel\"><param name=\"console\" value=\"one\"><param name=\"AutoStart\" value=\"true\"><embed src=\""+strURL+"\" type=\"audio/x-pn-realaudio-plugin\" nojava=\"true\" controls=\"ControlPanel,StatusBar\" console=\"one\" autostart=\"true\" width=\"350\" height=\"36\"></object>"
		}
		objMedia.innerHTML = strMedia;
	}
}
//*********************************************************




//*********************************************************
// 目的：    InsertQuote To txaArticle
// 输入：    无
// 返回：    无
//*********************************************************
function InsertQuote(strName,strText)
{
	objActive="txaArticle";

	var re;
	re=new RegExp("<br/?>","ig");
	strText=strText.replace(re, "\n");
	re=new RegExp("<[^>]*>","ig");
	strText=strText.replace(re, "");

	InsertText(objActive,"[QUOTE=",false);
	InsertText(objActive,strName,false);
	InsertText(objActive,"]",false);
	InsertText(objActive,strText,false);
	InsertText(objActive,"[/QUOTE]",false);
}
//*********************************************************

 function dialog(){
	var titile = '';
	var width = 300;
	var height = 180;
	var src = "";
	var path = str00+'IMAGE/COMMON/';
	var sFunc = '<input id="dialogOk" type="button" style="width:62px;height:22px;border:0;background:url(\'' + path + 'smb_btn_bg.gif\');line-height:20px;" value="确定" onclick="new dialog().reset();disableform(false);" />';
	var sClose = '<input type="image" id="dialogBoxClose" onclick="new dialog().reset();disableform(false);" src="' + path + 'dialogClose0.gif" border="0" width="17" height="17" onmouseover="this.src=\'' + path + 'dialogCloseF.gif\';" onmouseout="this.src=\'' + path + 'dialogClose0.gif\';" align="absmiddle" />';
	var sBody = '\
		<table id="dialogBodyBox" border="0" align="center" cellpadding="0" cellspacing="0">\
			<tr height="10"><td colspan="4"></td></tr>\
			<tr>\
				<td width="10"></td>\
				<td width="80" align="center" valign="absmiddle"><img id="dialogBoxFace" src="' + path + '3.gif" /></td>\
				<td id="dialogMsg" style="font-size:12px;color:#000;"></td>\
				<td width="10"></td>\
			</tr>\
			<tr height="10"><td colspan="4" align="center"></td></tr>\
			<tr><td id="dialogFunc" colspan="4" align="center">' + sFunc + '</td></tr>\
			<tr height="10"><td colspan="4" align="center"></td></tr>\
		</table>\
	';
	var sBox = '\
		<table id="dialogBox" width="' + width + 'px" border="0" cellpadding="0" cellspacing="0" style="border:1px solid #000;display:none;z-index:10;">\
			<tr height="1" bgcolor="#D6E3EB"><td></td></tr>\
			<tr height="25" bgcolor="#6795B4">\
				<td>\
					<table onselectstart="return false;" style="-moz-user-select:none;" width="100%" border="0" cellpadding="0" cellspacing="0">\
						<tr>\
							<td width="6"></td>\
							<td id="dialogBoxTitle" onmousedown="new dialog().moveStart(event, \'dialogBox\')" style="color:#fff;cursor:move;font-size:12px;font-weight:bold;">'+ str07 +'</td>\
							<td id="dialogClose" width="27" align="right" valign="middle">\
								' + sClose + '\
							</td>\
							<td width="6"></td>\
						</tr>\
					</table>\
				</td>\
			</tr>\
			<tr height="2" bgcolor="#EDEDED"><td></td></tr>\
			<tr id="dialogHeight" style="height:' + height + '">\
				<td id="dialogBody" style="background:#fff;color:#000;">' + sBody + '</td>\
			</tr>\
		</table>\
		<div id="dialogBoxShadow" style="display:none;z-index:9;"></div>\
	';
	function $(_sId){return document.getElementById(_sId)}
	this.show = function(){$('dialogBodyBox') ? function(){} : this.init();this.middle('dialogBox');this.shadow();}
	this.reset = function(){this.hideModule('select', '');$('dialogBox').style.display='none';$('dialogBoxShadow').style.display = "none";$('dialogBody').innerHTML = sBody;}
	this.html = function(_sHtml){$("dialogBody").innerHTML = _sHtml;this.show();}
	this.init = function(){
		$('dialogCase') ? $('dialogCase').parentNode.removeChild($('dialogCase')) : function(){};
		var oDiv = document.createElement('span');
		oDiv.id = "dialogCase";
		oDiv.innerHTML = sBox;
		document.body.appendChild(oDiv);
	}
	this.button = function(_sId, _sFuc){
		if($(_sId)){
			$(_sId).style.display = '';
			if($(_sId).addEventListener){
				if($(_sId).act){$(_sId).removeEventListener('click', function(){eval($(_sId).act)}, false);}
				$(_sId).act = _sFuc;
				$(_sId).addEventListener('click', function(){eval(_sFuc)}, false);
			}else{
				if($(_sId).act){$(_sId).detachEvent('onclick', function(){eval($(_sId).act)});}
				$(_sId).act = _sFuc;
				$(_sId).attachEvent('onclick', function(){eval(_sFuc)});
			}
		}
	}
	this.shadow = function(){
		var oShadow = $('dialogBoxShadow');
		var oDialog = $('dialogBox');
		oShadow['style']['position'] = "absolute";
		oShadow['style']['background']	= "#000";
		oShadow['style']['display']	= "";
		oShadow['style']['opacity']	= "0.2";
		oShadow['style']['filter'] = "alpha(opacity=20)";
		//oDialog['style']['filter'] = "alpha(opacity=90)";
		oShadow['style']['top'] = oDialog.offsetTop + 6+ 'px';
		oShadow['style']['left'] = oDialog.offsetLeft + 6+ 'px';
		oShadow['style']['width'] = oDialog.offsetWidth+ 'px';
		oShadow['style']['height'] = oDialog.offsetHeight+ 'px';
	}
	this.event = function(_sMsg, _sOk){
		$('dialogFunc').innerHTML = sFunc;
		$('dialogClose').innerHTML = sClose;
		$('dialogBodyBox') == null ? $('dialogBody').innerHTML = sBody : function(){};
		$('dialogMsg') ? $('dialogMsg').innerHTML = _sMsg  : function(){};
		this.show();
		_sOk ? this.button('dialogOk', _sOk) | $('dialogOk').focus() : $('dialogOk').style.display = 'none';
	}
	this.set = function(_oAttr, _sVal){
		var oShadow = $('dialogBoxShadow');
		var oDialog = $('dialogBox');
		var oHeight = $('dialogHeight');

		if(_sVal != ''){
			switch(_oAttr){
				case 'title':
					$('dialogBoxTitle').innerHTML = _sVal;
					title = _sVal;
					break;
				case 'width':
					oDialog['style']['width'] = _sVal;
					width = _sVal;
					break;
				case 'height':
					oHeight['style']['height'] = _sVal;
					height = _sVal;
					break;
				case 'src':
					if(parseInt(_sVal) > 0){
						$('dialogBoxFace') ? $('dialogBoxFace').src = path + _sVal + '.gif' : function(){};
					}else{
						$('dialogBoxFace') ? $('dialogBoxFace').src = _sVal : function(){};
					}
					src = _sVal;
					break;
			}
		}
		this.middle('dialogBox');
		oShadow['style']['top'] = oDialog.offsetTop + 6 + 'px';
		oShadow['style']['left'] = oDialog.offsetLeft + 6 + 'px';
		oShadow['style']['width'] = oDialog.offsetWidth + 'px';
		oShadow['style']['height'] = oDialog.offsetHeight + 'px';
	}
	this.moveStart = function (event, _sId){
		var oObj = $(_sId);
		oObj.onmousemove = mousemove;
		oObj.onmouseup = mouseup;
		oObj.setCapture ? oObj.setCapture() : function(){};
		oEvent = window.event ? window.event : event;
		var dragData = {x : oEvent.clientX, y : oEvent.clientY};
		var backData = {x : parseInt(oObj.style.top), y : parseInt(oObj.style.left)};
		function mousemove(){
			var oEvent = window.event ? window.event : event;
			var iLeft = oEvent.clientX - dragData["x"] + parseInt(oObj.style.left);
			var iTop = oEvent.clientY - dragData["y"] + parseInt(oObj.style.top);
			oObj.style.left = iLeft + 'px';
			oObj.style.top = iTop+ 'px';
			$('dialogBoxShadow').style.left = iLeft + 6 + 'px';
			$('dialogBoxShadow').style.top = iTop + 6 + 'px';
			dragData = {x: oEvent.clientX, y: oEvent.clientY};
			
		}
		function mouseup(){
			var oEvent = window.event ? window.event : event;
			oObj.onmousemove = null;
			oObj.onmouseup = null;
			if(oEvent.clientX < 1 || oEvent.clientY < 1 || oEvent.clientX > document.body.clientWidth || oEvent.clientY > document.body.clientHeight){
				oObj.style.left = backData.y;
				oObj.style.top = backData.x;
				$('dialogBoxShadow').style.left = backData.y + 6;
				$('dialogBoxShadow').style.top = backData.x + 6;
			}
			oObj.releaseCapture ? oObj.releaseCapture() : function(){};
		}
	}
	this.hideModule = function(_sType, _sDisplay){
		var aType = document.getElementsByTagName(_sType);
		for (var i = 0; i < aType.length; i++){
			aType[i].style.display	= _sDisplay;
		}
		
	}
	this.middle = function(_sId){
		$(_sId)['style']['display'] = '';
		$(_sId)['style']['position'] = "absolute";
		$(_sId)['style']['left'] = (document.documentElement.clientWidth / 2) - ($(_sId).offsetWidth / 2)  + 'px' ;
		$(_sId)['style']['top'] = (document.documentElement.clientHeight / 2 + document.documentElement.scrollTop) - ($(_sId).offsetHeight / 2) + 'px';
		}
}

function $(_sId){return document.getElementById(_sId)}

function getSend(){
	var sCurrTime = Math.floor((new Date() - SENDTIME)/1000);
	return sCurrTime < 0 ? 9999 : sCurrTime;
}

function initSendTime(){
	SENDTIME = new Date();
}

var SENDTIME = new Date("2006","4","15","10","0","0");

function escape2(str){
	return escape(str).replace(/\+/g,"%2b");
}

var inpVerifyNumber=0;

function ShowVerify(){
	if (ZC_COMMENT_VERIFY_ENABLE)
	{
		$("Verify")['style']['display']= "";
	}
}
function CopyText(obj,msg){
	try
	{
	window.clipboardData.setData('text', obj.match(/http(.*)/gi)[0]);
	var sDialog = new dialog();
    sDialog.init();
	sDialog.event(msg.replace("%s",obj.match(/http(.*)/gi)[0]),'');
	sDialog.button('dialogOk','void 0');
	$('dialogOk').focus();
	return false;
	}
	catch (notIE){}
	
}
function resizeimg(obj){ 
if(obj.width> ZC_IMAGE_WIDTH)obj.width= ZC_IMAGE_WIDTH;  
} 
function openimg(obj){ 
window.open(obj.src); 
} 
function overimg(obj){ 
obj.style.cursor='hand'; 
obj.style.border='solid #cccccc 1px'; 
} 
function outimg(obj){ 
obj.style.border='none'; 
} 
function ReSizeFont(){
	document.write(ZC_MSG278+": <a href=\"javascript:SizeAdd();\">"+ZC_MSG276+"</a><a href=\"javascript:SizeMin();\">"+ZC_MSG277+"</a><a onclick=\"ChangeST2(this);\" href=\"javascript:ChangeST(2);\">"+ZC_MSG283+"</a>");
}

function SizeAdd(){

	var divs = document.getElementsByTagName("div");

		for (var i = 0; i < divs.length; i++)
		{
			var div = divs[i];
			
			if (div.className=="post-body")
			{
				if (div['style']['fontSize']=="")
				{
					div['style']['fontSize']=14 + 'px';

				}else{

					div['style']['fontSize']=Math.floor(div['style']['fontSize'].replace("px",''))+3+'px';
				}
				
			}
		}
}

function SizeMin(){

	var divs = document.getElementsByTagName("div");

		for (var i = 0; i < divs.length; i++)
		{
			var div = divs[i];
			
			if (div.className=="post-body")
			{
				if (div['style']['fontSize']=="")
				{
					div['style']['fontSize']=14 + 'px';

				}else{

					div['style']['fontSize']=Math.floor(div['style']['fontSize'].replace("px",''))-3+'px';
				}
				
			}
		}
}

function ChangeST() {
	var head = document.getElementsByTagName('head').item(0); 
	var script = document.createElement('script');
	script.src = str00+"SCRIPT/simp_trad.js";
	script.type = "text/javascript"; 
	head.appendChild(script);	
}


function ChangeST2(obj){
	if (ST=="S")
	{
		obj.innerText=ZC_MSG282;
	}else{
		obj.innerText=ZC_MSG283;
	}
}

function getHTTPObject() {
	var xmlhttprequest=false; 
	try {
		  xmlhttprequest = new XMLHttpRequest();
		} catch (trymicrosoft) {
	  try {
		xmlhttprequest = new ActiveXObject('Msxml2.XMLHTTP');
	  } catch (othermicrosoft) {
		try {
		  xmlhttprequest = new ActiveXObject('Microsoft.XMLHTTP');
		} catch (failed) {
		  xmlhttprequest = false;
		}
	  }
	}
	return xmlhttprequest;
}


function LoadComment(){  
var url =CommentURL+'?rnd=' + Math.random(); 
xmlhttp.open('GET', url, true);  
xmlhttp.onreadystatechange = UpdateCommentString;
xmlhttp.send(null);
}

function UpdateCommentString(){ 
if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ){ 
CommentString=xmlhttp.responseText; 
if(CommentString.length==0)return false;ShowComment(1) ;
} }

function Comment_Initialize(){
LoadComment(); 
}

function ShowComment(Page){
	var spanComments = document.getElementById('CommentStr');
	var PrintString=''; 
		if (ZC_COMMENT_MULTI_PAGE)
		{
		var matchArray = CommentString.match(/<ul(?:\s*|.*?)*<\/ul>/gi);
		var first=(matchArray.length-1)-((Page-1)*ZC_COMMENT_MULTI_PAGESIZE);
		var last=first-ZC_COMMENT_MULTI_PAGESIZE;
		for (var i=first;i>last;i--) 
		{if (typeof matchArray[i]!='undefined')PrintString=PrintString+matchArray[i];} 
		var Comment_Page=Comment_ShowPage(matchArray.length/ZC_COMMENT_MULTI_PAGESIZE,Page);
		PrintString =Comment_Page + PrintString + Comment_Page;
		}else{
		PrintString =CommentString;
		}
	spanComments.innerHTML = PrintString; 
} 



function Comment_ShowPage(MaxPage,Page){
MaxPage=Math.ceil(MaxPage); 
var str='';if (MaxPage==1) return str;
str=str+'<ul class=\"msg\"><li class=\"msgpage\">'+ZC_MSG013+ZC_MSG042+': ';
for (var i=1;i<=MaxPage;i++){
if (Page==i){
str=str+'<b><a href=\"javascript:ShowComment('+i+');\" style=\"color:red;\">['+i+']</a></b>';
}else{
str=str+'<a href=\"javascript:ShowComment('+i+');\">['+i+']</a>';
}}
str=str+'</li></ul>';return str;}


function disableform(func){
	$('txaArticle').disabled = func;
	$('btnSumbit').disabled = func;
	$('inpName').disabled = func;
	$('inpEmail').disabled = func;
	$('inpHomePage').disabled = func;
	$('inpVerify').disabled = func;	
	$('chkLogin').disabled = func;	
	$('chkReg').disabled = func;	
	$('inpPass').disabled = func;	
}

function showLogin(){
	if ($('chkLogin').checked==true)
	{
		$('passForm')['style']['display']='';
		$('chkLogin').disabled=false;		
		$('chkReg').checked=false;
		$('chkReg').disabled=true;

	}else{
		$('passForm')['style']['display']='none';
		$('chkLogin').disabled=false;
		$('chkReg').disabled=false;
		$('chkReg').checked=false;
	}
}

function showPassForm(){

	if (ZC_REGISTER_ENABLE==false)
	{
		$('chkReg').disabled=true;	
		$('chkReg').checked=false;
		var sDialog = new dialog();
		sDialog.init();
		sDialog.event(ZC_MSG293,'');
		sDialog.button('dialogOk','disableform(false);');
		$('dialogOk').focus();			
		return false;
	}

	if ($('chkReg').checked==true)
	{
		$('passForm')['style']['display']='';
		$('chkReg').disabled=false;		
		$('chkLogin').checked=false;
		$('chkLogin').disabled=true;

	}else{
		$('passForm')['style']['display']='none';
		$('chkReg').disabled=false;
		$('chkLogin').disabled=false;
		$('chkLogin').checked=false;
	}
}



var CommentString; var xmlhttp = getHTTPObject(); var Page; var ST="S";