﻿///////////////////////////////////////////////////////////////////////////////
//              Z-Blog
// 作    者:    朱煊(zx.asd)
// 版权所有:    RainbowSoft Studio
// 技术支持:    rainbowsoft@163.com
// 程序名称:    
// 程序版本:    
// 单元名称:    common.js
// 开始时间:    2004.07.25
// 最后修改:    
// 备    注:    全局脚本
///////////////////////////////////////////////////////////////////////////////


var ZC_UBB_FACE_FILENAME="Sly smile|Big smile|Biggest smile|Tease|Starry|Flattered|Boy smile|Girl smile 3|Happy|Kissed|Surprise|Split|Fright|Capo mafioso|Sad|Bad surprise|Fear|Closed up|Cry|Fury|Alien|Bloody|Bomb|Hatred|Song|Prodigy|Snowman|Yin-yang|Mail|Blue"

//*********************************************************
// 目的：    加载样式表
// 输入：    无
// 返回：    无
//*********************************************************
function LoadActiveStyleSheet(){

	var title=GetCookie("sk")
	var a;

	if (title) {

		a = document.getElementsByTagName("link")[0];

		a.href=str00+"style/"+title+".css"

	}

}
//*********************************************************




//*********************************************************
// 目的：    设置样式表
// 输入：    title
// 返回：    无
//*********************************************************
function SetActiveStyleSheet(title){

	var a;

	if (title) {

		{
			SetCookie("sk",title,365);
		}
		a = document.getElementsByTagName("link")[0];

		a.href=str00+"style/"+title+".css"

	}

}
//*********************************************************




//*********************************************************
// 目的：    设置Cookie
// 输入：    sName, sValue,iExpireDays
// 返回：    无
//*********************************************************
function SetCookie(sName, sValue,iExpireDays) {
	if (iExpireDays){
		var dExpire = new Date();
		dExpire.setTime(dExpire.getTime()+parseInt(iExpireDays*24*60*60*1000));
		document.cookie = sName + "=" + escape(sValue) + "; expires=" + dExpire.toGMTString();
	}
	else{
		document.cookie = sName + "=" + escape(sValue);
	}
}
//*********************************************************




//*********************************************************
// 目的：    返回Cookie
// 输入：    Name
// 返回：    Cookie值
//*********************************************************
function GetCookie(sName) {

	var arr = document.cookie.match(new RegExp("(^| )"+sName+"=([^;]*)(;|$)"));
	if(arr !=null){return unescape(arr[2])};
	return null;

}
//*********************************************************




//*********************************************************
// 目的：    验证信息
// 输入：    无
// 返回：    无
//*********************************************************
function VerifyMessage() {

	var strName=document.getElementById("inpName").value;
	var strEmail=document.getElementById("inpEmail").value;
	var strHomePage=document.getElementById("inpHomePage").value;
	var strArticle;

	if(document.getElementById("txaArticle").value){
		strArticle=document.getElementById("txaArticle").value;
	}
	else{
		strArticle=document.getElementById("txaArticle").innerText;
	}

	if(strName==""){
		alert(str01);
		return false;
	}
	else{
		re = new RegExp("^[.A-Za-z0-9\u4e00-\u9fa5]+$");
		if (!re.test(strName)){
			alert(str02);
			return false;
		}
	}

	if(strEmail==""){
		alert(str01);
		return false;
	}
	else{
		re = new RegExp("^[\\w-]+(\\.[\\w-]+)*@[\\w-]+(\\.[\\w-]+)+$");
		if (!re.test(strEmail)){
			alert(str02);
			return false;
		}
	}

	if(typeof(strArticle)=="undefined"){
		alert(str03);
		return false;
	}

	if(typeof(strArticle)=="string"){
		if(strArticle==""){
			alert(str03);
			return false;
		}
		if(strArticle.length>intMaxLen)
		{
			alert(str03);
			return false;
		}
	}

	document.getElementById("inpArticle").value=strArticle;
	document.getElementById("inpLocation").value=parent.window.location.href;
	document.getElementById("frmSumbit").action=str00+"cmd.asp?act=cmt";


	var bolRemember=document.getElementById("chkRemember").checked;

	if(bolRemember==true){
		SaveRememberInfo();
	}
	else{
		SetCookie("chkRemember",bolRemember,365);
	}

}
//*********************************************************




//*********************************************************
// 目的：    加载信息
// 输入：    无
// 返回：    无
//*********************************************************
function LoadRememberInfo() {

	var strName=GetCookie("inpName")
	var strEmail=GetCookie("inpEmail")
	var strHomePage=GetCookie("inpHomePage")
	var bolRemember=GetCookie("chkRemember")

	if(bolRemember=="true"){

		if(strName){document.getElementById("inpName").value=strName;};
		if(strEmail){document.getElementById("inpEmail").value=strEmail;};
		if(strHomePage){document.getElementById("inpHomePage").value=strHomePage;};
		if(bolRemember){document.getElementById("chkRemember").checked=bolRemember;};

	}

}
//*********************************************************




//*********************************************************
// 目的：    保存信息
// 输入：    无
// 返回：    无
//*********************************************************
function SaveRememberInfo() {

	var strName=document.getElementById("inpName").value;
	var strEmail=document.getElementById("inpEmail").value;
	var strHomePage=document.getElementById("inpHomePage").value;
	var bolRemember=document.getElementById("chkRemember").checked;


	SetCookie("inpName",strName,365);
	SetCookie("inpEmail",strEmail,365);
	SetCookie("inpHomePage",strHomePage,365);
	SetCookie("chkRemember",bolRemember,365);

}
//*********************************************************





//*********************************************************
// 目的：    输出UBB
// 输入：    无
// 返回：    无
//*********************************************************
function ExportUbbFrame() {

	objActive="txaArticle";

	document.write("<p id=\"UbbFrame\" style=\"display:none;\">")

	var aryFileName;
	var strFileName;
	aryFileName = ZC_UBB_FACE_FILENAME.split("|");

	for (var i=0;i<aryFileName.length;i++)
	{
		strFileName = aryFileName[i];
		document.write("<img src=\""+str00+"image/face/"+strFileName+".gif\" title=\""+strFileName+"\" alt=\""+strFileName+"\" width=\"48\" height=\"48\" onclick=\"InsertText(objActive,'[F]'+this.alt+'[/F]',false);\" style=\"padding:2px;cursor:pointer;\">")
	}

	document.write("</p><p>")

	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[URL]','[/URL]'),true);\" style=\"padding:2px;cursor:pointer;\">[URL]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[URL=http://]','[/URL]'),true);\" style=\"padding:2px;cursor:pointer;\">[URL2]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[EMAIL]','[/EMAIL]'),true);\" style=\"padding:2px;cursor:pointer;\">[EMAIL]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[EMAIL=@]','[/EMAIL]'),true);\" style=\"padding:2px;cursor:pointer;\">[EMAIL2]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[B]','[/B]'),true);\" style=\"padding:2px;cursor:pointer;\">[B]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[I]','[/I]'),true);\" style=\"padding:2px;cursor:pointer;\">[I]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[U]','[/U]'),true);\" style=\"padding:2px;cursor:pointer;\">[U]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[S]','[/S]'),true);\" style=\"padding:2px;cursor:pointer;\">[S]</a>  ")
	document.write("<a alt=\"\" onmousedown=\"InsertText(objActive,ReplaceText(objActive,'[QUOTE]','[/QUOTE]'),true);\" style=\"padding:2px;cursor:pointer;\">[QUOTE]</a>  ")

	document.write("<u><a style=\"cursor:pointer;text-align:right;\" onclick=\"if(document.getElementById('UbbFrame').style.display=='none'){document.getElementById('UbbFrame').style.display='block';}else{document.getElementById('UbbFrame').style.display='none'};this.style.display='none'\">"+str06+"</a></u> ")

	document.write("</p>")
}
//*********************************************************




//*********************************************************
// 目的：    自动插入并替换
// 输入：    无
// 返回：    无
//*********************************************************
var objActive;
function GetActiveText(objHTML) {
	objActive=objHTML;
	if(document.selection){
		var obj=document.getElementById(objHTML);
		obj.currPos = document.selection.createRange().duplicate()
	}
}

function InsertText(objHTML,strText,bolReplace) {
	if(strText==""){return("")}
	var obj=document.getElementById(objHTML);
	if(document.selection){
		if (obj.currPos){
			if(bolReplace && (obj.value=="")){
				obj.currPos.text=strText
			}
			else{
				obj.currPos.text+=strText
			}
		}
		else{
			obj.value+=strText
		}
	}
	else{
		if(bolReplace){
			obj.value=obj.value.slice(0,obj.selectionStart) + strText + obj.value.slice(obj.selectionEnd,obj.value.length)
		}
		else{
			obj.value=obj.value.slice(0,obj.selectionStart) + strText + obj.value.slice(obj.selectionStart,obj.value.length)
		}
	}
	//obj.focus();
}

function ReplaceText(objHTML,strPrevious,strNext) {
	var obj=document.getElementById(objHTML);
	var strText;
	if(document.selection && document.selection.type == "Text"){
		if (obj.currPos){
			var range = document.selection.createRange();
			range.text = strPrevious + range.text + strNext;
			return("");
		}
		else{
			strText=strPrevious + strNext;
			return(strText);
		}
	}
	else{
		if(obj.selectionStart || obj.selectionEnd){
			strText=strPrevious + obj.value.slice(obj.selectionStart,obj.selectionEnd) + strNext;
			return(strText);
		}
		else{
			strText=strPrevious + strNext;
			return(strText);
		}
	}
}
//*********************************************************




//*********************************************************
// 目的：    ShowMedia By UBB
// 输入：    无
// 返回：    无
//*********************************************************
function ShowMedia(objHTML,strURL,strType,intWidth,intHeight)
{
	var strMedia="";
	var blnShow = false;
	var objMedia=objHTML;

	if(objMedia.innerHTML){blnShow = true};

	var re = new RegExp("\.[a-z0-9]+$","ig");

	var strExtend = re.exec(strURL);
	strExtend="|"+String(strExtend).toLowerCase()+"|";

	if(strType=="AUTO"){
		if(String("|.swf|").indexOf(strExtend)>=0){strType="SWF"}
		if(String("|.mov|.qt|").indexOf(strExtend)>=0){strType="QT"}
		if(String("|.wmv|.wmp|.wm|.avi|.mp4|.mpg|.mpeg|.m3u|.pls|.wvx|.wax|.wmx|").indexOf(strExtend)>=0){strType="WMV"}
		if(String("|.asf|.wma|.asx|.wav|.mp3|.mpa|.mp2|.m1a|.m2a|.aac|").indexOf(strExtend)>=0){strType="WMA"}
		if(String("|.rm|.ram|.rmvb|.rpm|.amr|.3gp|.3gpp|.3g2|.3gp2|.rt|.rp|.smi|.smil|").indexOf(strExtend)>=0){strType="RM"}
		if(String("|.ra|").indexOf(strExtend)>=0){strType="RA"}
	}

	if(blnShow){
		objMedia.innerHTML = strMedia;
	}
	else{
		switch(strType){
			case "SWF":
				strMedia="<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\""+intWidth+"\" height=\""+intHeight+"\"><param name=\"movie\" value=\""+strURL+"\"><param name=\"quality\" value=\"high\"><param name=\"play\" value=\"true\"><embed src=\""+strURL+"\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\""+intWidth+"\" height=\""+intHeight+"\" play=\"true\"></embed></object>"
				break;
			case "QT":
				strMedia="<object classid=\"CLSID:02bf25d5-8c17-4b23-bc80-d3488abddc6b\" codebase=\"http://www.apple.com/qtactivex/qtplugin.cab\" width=\""+intWidth+"\" height=\""+intHeight+"\" ><param name=\"src\" value=\""+strURL+"\" ><param name=\"autoplay\" value=\"true\" ><embed  src=\"qtmimetype.pntg\" type=\"image/x-macpaint\"pluginspage=\"http://www.apple.com/quicktime/download\" qtsrc=\""+strURL+"\" width=\""+intHeight+"\" height=\""+intHeight+"\" autoplay=\"true\" ></embed></object>"
				break;
			case "WMV":
				strMedia="<object classid=\"CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95\"  width=\""+intWidth+"\" height=\""+intHeight+"\"><param name=\"ShowStatusBar\" value=\"-1\"><param name=\"AutoStart\" value=\"true\"><param name=\"Filename\" value=\""+strURL+"\"></object>"
				break;
			case "WMA":
				strMedia="<object classid=\"CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95\" height=\"45\" width=\"350\"><param name=\"ShowStatusBar\" value=\"-1\"><param name=\"AutoStart\" value=\"true\"><param name=\"Filename\" value=\""+strURL+"\"><embed type=\"application/x-mplayer2\" pluginspage=\"http://www.microsoft.com/Windows/MediaPlayer/\" src=\""+strURL+"\" autostart=\"true\" width=\"350\" height=\"45\"></embed></object>"
				break;
			case "RM":
				strMedia="<object classid=\"CLSID:cfcdaa03-8be4-11cf-b84b-0020afbbccfa\" width=\""+intWidth+"\" height=\""+intWidth+"\"><param name=\"src\" value=\""+strURL+"\"><param name=\"controls\" value=\"imagewindow\"><param name=\"console\" value=\"one\"><param name=\"AutoStart\" value=\"true\"><embed src=\""+strURL+"\" width=\""+intWidth+"\" height=\""+intWidth+"\" nojava=\"true\" controls=\"imagewindow\" console=\"one\" autostart=\"true\"></object>"
				break;
			case "RA":
				strMedia="<object classid=\"CLSID:cfcdaa03-8be4-11cf-b84b-0020afbbccfa\" width=\"350\" height=\"36\"><param name=\"src\" value=\""+strURL+"\"><param name=\"controls\" value=\"ControlPanel\"><param name=\"console\" value=\"one\"><param name=\"AutoStart\" value=\"true\"><embed src=\""+strURL+"\" nojava=\"true\" controls=\"imagewindow\" console=\"one\" autostart=\"true\" width=\"350\" height=\"36\"></object>"
		}
		objMedia.innerHTML = strMedia;
	}
}
//*********************************************************