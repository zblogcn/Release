﻿Z-Blog 个人版

软件授权使用协议:

您开始使用已授权的软件表示您已经接受了以下的授权使用协议。

1.本软件为免费软件，您可安装无限制数量的本软件产品来使用。
2.本软件产品只许可免费使用，不得出售，不收取任何费用，不得用于商业目的的活动之中。
3.请尊重作者的版权，不得移除RainbowSoft及Z-Blog的标识。
4.作者对使用本软件所涉及任何间接或直接后果包括利益、数据等方面的任何损失概不负责。
您因使用本软件产品所造成之任何损失和风险将由您独自承担。



系统配置:

服务器：Windows 2000及IIS5.0以上，需要ADO数据库、FSO、XMLDOM等系统组件支持，具体请查询网络服务商或查看本机配置。
客户端：支持IE6.0、Mozilla FireFox 1.0、Opear 8.0浏览器。客户端浏览器需要启用JavaScript脚本支持。



使用说明:

1.请先将c_custom.asp文件中的 ZC_BLOG_HOST 更改为已分配的IP或域名。
格式要是"http://aaa.bbb.ccc/"，前面要加 http:// ,后面要加上 / 。


2.将DATA目录下的数据库改为一个比较复杂的名称。
再更改 ZC_DATABASE_PATH 值为 "data/你的数据库名称" ，数据库只能放在DATA目录下。


3.系统初始设有一个管理员账号，在登陆后，请修改名称和密码。
用户名：zblogger
密  码：zblogger
管理员可以创建比自己权限低的账号，推荐建立一个“高级用户”供日常使用。


4.在[全局管理]中更改你的BLOG名称等等，也包括更换CSS界面样式。
在设置完成之后请点[文件重建]以让所有的日志页面都生效。


5.先在[分类管理]建立一个分类，才可以到[文章管理]中添加新日志文章。
只有管理员才有分类创建或删除的权限。


6.在[文章管理]中添加、编辑或删除文章。
要在文章提交完成之后才能用该文章向对方的BLOG发送引用。
请自行提取正文的文字做为摘要，系统的自动截断功能有可能会使正文页面显示不正常。


7.什么时候需要点击[索引重建]？
[索引重建]让系统刷新统计数据和缓存，同时，生成该BLOG的RSS 2.0聚合的XML文件于根目录中。
每次发表文章、修改分类及用户等等后需要点击[索引重建]。


8.什么时候需要点击[文件重建]？
当你在[Blog管理]更改了相应的值，都需要使用“文件重建”以使每个文章页面更改生效。
“文件重建”是一个消耗资源与时间的事件，尤其是BLOG中日志数量太多时。


9.关于“导航栏”请在INCLUDE目录下的navbar.asp文件中修改相应的HTML代码。
同样，关于“网站收藏”、“友情链接”和“图标汇集”分别在favorite.asp、link.asp和misc.asp文件中修改。
它们的格式都是：
<li><a href="http://www.rainbowsoft.org/zblog/" target="_blank">布罗格的烘培机</a></li>


10.如何让日志显示源代码，包括HTML，ASP，PHP等，请用“[ CODE ]”“[/ CODE ]”
或“[CODE_LITE] ”“[/CODE_LITE]”将源程序包含就行了。
UBB代码请参考官方主页上的介绍。


11.附件都上传在UPLOAD目录中，只能上传限定类型的文件。
请用IE或FireFox上传全ASCII字符名称的文件。
具体设置在c_option.asp文件ZC_UPLOAD_FILETYPE和ZC_UPLOAD_FILESIZE中设置。


12.如何在日志中引用附件呢?
请用以下格式，系统会自动将相对路径替代成绝对路径。
<a href="upload/abc.zip" alt="xxx" title="xxx">xxx</a>
<img src="upload/abc.jpg" alt="xx" title="xxx" width="xx" height="xx" />


13.如何在一个网站中使用超过两个以上的Z-Blog程序？
打开每个BLOG的c_option.asp文件，将ZC_BLOG_CLSID设置为不同的值即可。


14.Z-Blog的XML-RPC功能如何使用？
Z-Blog的XML-RPC接口采用MetaWeblog的API，可以在相应软件和网站调用该URL:
http://yourblog/xml-rpc/index.asp


版权申明:

Z-Blog程序版权归作者 朱烜(zx.asd) 所有。
本程序除了原创样式以外的其它样式的版权均归其作者或网站、公司所有。
本程序所采用的表情图片版权归 VladZ 所有。
Wap for Z-Blog程序版权归 明月星光 所有。



/////////////////////////////////////////////////////////////////////////
版权所有 (c) 1999-2005  RainbowSoft Studio,朱烜(zx.asd).

网址：http://www.rainbowsoft.org/
电邮：rainbowsoft@163.com
论坛：http://www.zblogger.net/bbs/

技术支持：http://www.rainbowsoft.org/zblog/