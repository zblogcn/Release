<!DOCTYPE html>
<html>
<head>
    <title>表格删除提示</title>
    <script type="text/javascript" src="../internal.js"></script>
    <style type="text/css">
        .section {
            width: 200px;
            margin: 10px auto 0;
            font-size: 14px;
        }

        .item {
            text-align: center;
        }
    </style>
</head>
<body>
<div class="section">
    <div class="item">
        <label><input type="radio" id="J_delRow" name="cmd" checked/><var id="lang_delRow"></var></label>
    </div>
    <div class="item">
        <label><input type="radio" id="J_delCol" name="cmd"/><var id="lang_delCol"></var></label>
    </div>
</div>
<script type="text/javascript">
    dialog.onok = function () {
        $G("J_delRow").checked ? editor.execCommand("deleterow") : editor.execCommand("deletecol");
    };
</script>
</body>
</html>