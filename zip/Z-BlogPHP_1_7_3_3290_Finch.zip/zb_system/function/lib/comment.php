<?php

if (!defined('ZBP_PATH')) {
    exit('Access denied');
}

class Comment extends Base__Comment
{

}
