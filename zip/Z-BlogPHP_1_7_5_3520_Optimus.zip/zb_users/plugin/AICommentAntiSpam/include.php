<?php

define('AICommentAntiSpam_Version',1.2);
require_once dirname(__FILE__) . '/vendor/autoload.php';
require_once dirname(__FILE__) . '/includes/plugin_function.php';


RegisterPlugin("AICommentAntiSpam","ActivePlugin_AICommentAntiSpam");