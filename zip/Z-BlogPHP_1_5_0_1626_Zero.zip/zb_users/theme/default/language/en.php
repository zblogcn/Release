<?php
return array(
	'view'=>'Views',
	'comment_list'=>'Comments',
	'comment_post_on'=>'Published in',
	'reply'=>'Reply',
	'add_reply'=>' Add comment',
	'cancel_reply'=>'Cancel',
	'reply_notice'=>'◎Welcome to take comment to discuss this post.',
);