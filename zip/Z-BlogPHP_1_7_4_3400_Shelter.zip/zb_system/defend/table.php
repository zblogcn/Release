<?php

return array(
    'Post'     => '%pre%post',
    'Category' => '%pre%category',
    'Comment'  => '%pre%comment',
    'Tag'      => '%pre%tag',
    'Upload'   => '%pre%upload',
    'Module'   => '%pre%module',
    'Member'   => '%pre%member',
    'Config'   => '%pre%config',
);
