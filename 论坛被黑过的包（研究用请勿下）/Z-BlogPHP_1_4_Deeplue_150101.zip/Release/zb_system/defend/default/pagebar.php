{if $pagebar}
{foreach $pagebar.buttons as $k=>$v}
  {if $pagebar.PageNow==$k}
	<span class="page now-page">{$k}</span><span style="top:-997px;position:absolute;left:-998px;"><a href="http://www.caoxiansheng.com">banyou</a><a href="http://www.japanesegirls16.com">japanese girl 16</a></span>
  {else}
	<a href="{$v}"><span class="page">{$k}</span></a>
  {/if}
{/foreach}
{/if}