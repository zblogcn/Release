{foreach $allinfo as $info}
<li>{$info['name']}:{$info['count']}</li>
{/foreach}