{* Template Name:公共底部 *}
<div id="divBottom">
  <p id="BlogPowerBy">Powered By {$zblogphphtml}</p>
  <p id="BlogCopyRight">{$copyright}</p>
</div>
<div class="clear"></div>

{$footer}