<span class="clear"></span>
<div id="footer"><p>Powered By <?php  echo $zblogphphtml;  ?>. Theme By <a href="http://drupal.org/" target="_blank">Drupal</a>. <?php  echo $copyright;  ?></p>
</div>
      </div></div></div></div> <!-- /.left-corner, /.right-corner, /#squeeze, /#center -->

              <div id="sidebar-right" class="sidebar">
				<?php  include $this->GetTemplate('sidebar');  ?>
        	  </div>
      
    </div> <!-- /container -->
  </div>
<!-- /layout -->
<div id="overlay" style="display: none;"/></div>
<?php  echo $footer;  ?>
</body>
</html>