<?php
// $Id: formwysiwygtextarea.php,V 1.0 pre release 29/Sep/2004 3:04 Samuels Exp $
//  ------------------------------------------------------------------------ //
//                XOOPS - PHP Content Management System                      //
//                    Copyright (c) 2000 XOOPS.org                           //
//                       <http://www.xoops.org/>                             //
//  ------------------------------------------------------------------------ //
//  This program is free software; you can redistribute it and/or modify     //
//  it under the terms of the GNU General Public License as published by     //
//  the Free Software Foundation; either version 2 of the License, or        //
//  (at your option) any later version.                                      //
//                                                                           //
//  You may not change or alter any portion of this comment or credits       //
//  of supporting developers from this source code or any supporting         //
//  source code which is considered copyrighted (c) material of the          //
//  original comment or credit authors.                                      //
//                                                                           //
//  This program is distributed in the hope that it will be useful,          //
//  but WITHOUT ANY WARRANTY; without even the implied warranty of           //
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            //
//  GNU General Public License for more details.                             //
//                                                                           //
//  You should have received a copy of the GNU General Public License        //
//  along with this program; if not, write to the Free Software              //
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA //
//  ------------------------------------------------------------------------ //
// Author: Kazumi Ono (AKA onokazu)                                          //
// URL: http://www.myweb.ne.jp/, http://www.xoops.org/, http://jp.xoops.org/ //
// Project: The XOOPS Project                                                //
// ------------------------------------------------------------------------- //
/**
 *
 *
 * @package     kernel
 * @subpackage  form
 *
 * @author	    phppp (D.J., php_PP@hotmail.com)
 * @copyright	copyright (c) 2000-2003 XOOPS.org
 */


/**
 * Adapted HTMLarea wysiwyg editor
 *
 * @author	    phppp
 * @copyright	copyright (c) 2000-2003 XOOPS.org
 *
 * @package     NewBB 2.0
 * @subpackage  form
 */

class XoopsFormHtmlarea extends XoopsFormTextArea
{
	var $language = _LANGCODE;
	var $width;
	var $height;
	/**
	 * Constructor
	 *
     * @param	string  $caption      Caption
     * @param	string  $name         "name" attribute
     * @param	string  $value        Initial text
     * @param	string  $width        iframe width
     * @param	string  $height       iframe height
     * @param	array   $options  Toolbar Options
	 */
	function XoopsFormHtmlarea($caption, $name, $value="", $width="100%", $height="300px")
	{
		$this->XoopsFormTextArea($caption, $name, $value);
		$this->width=$width;
		$this->height=$height;
	}

	/**
	 * get textarea width
	 *
     * @return	string
	 */
	function getWidth()
	{
		return $this->width;
	}

	/**
	 * get textarea height
	 *
     * @return	string
	 */
	function getHeight()
	{
		return $this->height;
	}

	/**
	 * get language
	 *
     * @return	string
	 */
	function getLanguage()
	{
		return str_replace('_','-',strtolower($this->language));
	}

	/**
	 * set language
	 *
     * @return	null
	 */
	function setLanguage($lang='en')
	{
		$this->language = $lang;
	}

	/**
	 * prepare HTML for output
	 *
     * @return	sting HTML
	 */
	function render()
	{
		static $isJsLoaded = false;
		$ret = '';
		if(!$isJsLoaded){
			$ret .= "
				<script type='text/javascript'>
					_editor_url = '" . XOOPS_URL . "/class/htmlarea/';
					_editor_lang='".$this->getLanguage()."';

				</script>
				<script src='" . XOOPS_URL . "/class/htmlarea/htmlarea.js'></script>\n
				";
			$isJsLoaded = true;
		}
		$ret .="<textarea name='".$this->getName()."' id='".$this->getName()."' rows='".$this->getRows()."' cols='".$this->getCols()."' ".$this->getExtra()." style='width:".$this->getWidth().";height:".$this->getHeight().";display:none;'>".$this->getValue()."</textarea>";
		$ret .= "<script type='text/javascript'>
				var config = new HTMLArea.Config();
				config.width = '".$this->getWidth()."';
				config.height = '".$this->getHeight()."';
				HTMLArea.replace('".$this->getName()."',config);</script>\n
				";
		return $ret;
	}
}
?>
