<?php

if (!defined('ZBP_PATH')) {
    exit('Access denied');
}

/**
 * Tag类.
 */
class Tag extends Base__Tag
{

}
