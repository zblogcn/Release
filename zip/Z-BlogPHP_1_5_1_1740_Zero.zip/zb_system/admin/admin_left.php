<aside class="left">
  <ul id="leftmenu">
<?php
ResponseAdmin_LeftMenu()
?>
  </ul>
</aside>