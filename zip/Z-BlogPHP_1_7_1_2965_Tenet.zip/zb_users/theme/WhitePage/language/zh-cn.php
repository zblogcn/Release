<?php

return array(
    'theme_name'      => 'WhitePage主题',
    'theme_config'    => '主题配置',
    'global_settings' => '整体设置',
    'page_type'       => '页面类型',
    'text_indent'     => '正文缩进',
    'none'            => '无',
    'standard'        => '标准',
    'display_avatar'  => '显示评论头像',
    'super_fast_mode' => '超级速模式',
    'color_config'    => '颜色配置',
    'background_color'=> '背景色',
    'page_color'      => '页面颜色',
    'font_color'      => '字体颜色',
    'title_color'     => '标题颜色',
    'a_color'         => '链接颜色',
    'active_a_color'  => '链接选定颜色',
    'save'            => '保存配置',
    'only_one_cssjs'  => '只加载一个css和一个js',
    'shadow'          => '阴影',
    'flat'            => '平面',
    'right_angle'     => '直角',
    'rounded_corner'  => '圆角',

);
