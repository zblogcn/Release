<span class="clear"></span>
<div id="footer"><p>Powered By {$zblogphphtml}. Theme By <a href="http://drupal.org/" target="_blank">Drupal</a>. {$copyright}</p>
</div>
      </div></div></div></div> <!-- /.left-corner, /.right-corner, /#squeeze, /#center -->

              <div id="sidebar-right" class="sidebar">
				{template:sidebar}
        	  </div>
      
    </div> <!-- /container -->
  </div>
<!-- /layout -->
<div id="overlay" style="display: none;"/></div>
{$footer}
</body>
</html>