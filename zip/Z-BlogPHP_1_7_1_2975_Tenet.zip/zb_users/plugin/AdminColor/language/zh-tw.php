<?php

return array(
    'closemenu'  => '折疊選單',
    'expandmenu' => '展開選單',
);
