{* Template Name:列表页单条置顶文章 *}
<div class="post istop">
	<h2 class="post-title">[置顶]<a href="{$article.Url}">{$article.Title}</a></h2>
</div>