 <div class="istop-post postistop post cate{$article.Category.ID}  auth{$article.Author.ID}">
	<div class="post_time"></div>
	<div class="post_r">
		<div class="post_body">
		<h2><a href="{$article.Url}" title="{$article.Title}">{$article.Title}</a></h2>
		</div>
	</div>
	<div class="clear"></div>
</div>